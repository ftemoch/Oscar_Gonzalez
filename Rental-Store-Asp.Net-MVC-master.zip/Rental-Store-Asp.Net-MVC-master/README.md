# Rental-Store-Asp.Net-MVC
It is A Movie rental Store Management System which is developed Using Asp.net MVC. This Web Application Performs basic CRUD operations like adding a Customer,Deleting Customer,Updating And Viewing Details and its same goes for Movies.
To Improve Look And Feel of Web Application 
-Bootstrap is used.
-Jqyery plugins like DataTable and Twitter-Typeahead.
-toastr Notifications.


#Roles

Superadmin - Responsible for creating other roles and can access all the Actions.
EmailId - superadmin@gmail.com
Password- Super admin12345  //where S(Capital) and (Space)between Super and admin12345

Admin - Responsible to access all actions except (To create Roles).
EmailId - admin1@gmail.com
Password - Admin 12345  //where A(Capital) and (Space)between  Admin and 12345

CanChangeMovies - Responsible to access all actions except Customers(Create and Delete ) operations.
EmailId - canchangemovies@gmail.com
Password - Canchangemovies 12345 //where C(capital) and (Space)between Canchangemovies and 12345

guest or other logins only able to access to Read only Customers And Movies List 
